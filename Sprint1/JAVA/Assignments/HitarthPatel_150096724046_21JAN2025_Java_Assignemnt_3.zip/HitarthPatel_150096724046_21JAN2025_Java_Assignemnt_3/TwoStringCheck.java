public class TwoStringCheck {
    public static void main(String[] args) {
        String str1 = "Hello";
        String str2 = "Hello";
        if (str1.equals(str2)) {
            System.out.println("Both strings contain the same data.");
        } else {
            System.out.println("Both strings do not contain the same data.");
        }
    }
}

