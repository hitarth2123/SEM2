public class Replace {
    public static void main(String[] args) {
        String word = "Hello World";
        if (word.contains("e")) {
            System.out.println("The letter 'e' is present in the word.");
        } else {
            System.out.println("The letter 'e' is not present in the word.");
        }
    }
}

