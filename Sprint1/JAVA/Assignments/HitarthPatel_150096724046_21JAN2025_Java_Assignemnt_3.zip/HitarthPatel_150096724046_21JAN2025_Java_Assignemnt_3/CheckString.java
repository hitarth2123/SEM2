public class CheckString {
       public static void main(String[] args) {
        String mainString = "Hello World";
        String subString = "Hello";
        System.out.println("Does '" + mainString + "' start with '" + subString + "'? " + mainString.startsWith(subString));
    }
}

