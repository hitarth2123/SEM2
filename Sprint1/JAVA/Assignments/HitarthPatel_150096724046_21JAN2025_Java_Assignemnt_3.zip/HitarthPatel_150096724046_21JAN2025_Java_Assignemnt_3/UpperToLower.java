public class UpperToLower {
    public static void main(String[] args) {
        String str = "HELLO WORLD";
        System.out.println("Original String: " + str);
        System.out.println("Lowercase String: " + str.toLowerCase());
    }
}

