class Implicit {
    public static void main(String[] args) {
        int x = 10;
        double y = x;
        System.out.println("Print y:"+" "+y+"     "+"Print x:"+" "+x);

    }
    
}
