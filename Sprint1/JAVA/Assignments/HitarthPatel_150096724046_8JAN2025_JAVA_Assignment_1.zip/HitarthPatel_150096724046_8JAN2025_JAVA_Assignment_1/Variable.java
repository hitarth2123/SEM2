
public class Variable {
    public static void main(String[] args) {
        // Byte variable
        byte byteVar = 12;
        System.out.println("Byte variable: " + byteVar);

        // Short variable
        short shortVar = 3123;
        System.out.println("Short variable: " + shortVar);

        // Int variable
        int intVar = 211231231;
        System.out.println("Int variable: " + intVar);

        // Long variable
        long longVar = 9213L;
        System.out.println("Long variable: " + longVar);

        // Float variable
        float floatVar = 31223.1239f;
        System.out.println("Float variable: " + floatVar);

        // Double variable
        double doubleVar = 1231.2312;
        System.out.println("Double variable: " + doubleVar);

        // Char variable
        char charVar = 's';
        System.out.println("Char variable: " + charVar);

        // Boolean variable
        boolean booleanVar = true;
        System.out.println("Boolean variable: " + booleanVar);

        // String variable 
        String stringVar = "Assignment of java";
        System.out.println("String variable: " + stringVar);
    }
}