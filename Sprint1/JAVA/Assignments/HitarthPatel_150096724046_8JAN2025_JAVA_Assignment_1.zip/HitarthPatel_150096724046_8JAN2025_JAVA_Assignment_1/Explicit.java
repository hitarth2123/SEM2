 class Explicit {
    public static void main(String[] args) {
        double x = 10.5;
        int y = (int) x; 
        System.out.println("Print y:"+" "+y+"     "+"Print x:"+" "+x);
    }
    
}
