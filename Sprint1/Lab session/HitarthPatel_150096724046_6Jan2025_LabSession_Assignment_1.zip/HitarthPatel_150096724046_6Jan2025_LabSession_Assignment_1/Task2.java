
 /*
   Task 2: Store Student Details
    Store:
    Name
    Roll Number
    Three subject marks
    */ 
import java.util.Scanner;

class Task2 {
    public static void main(String[]args){
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter your name : ");
        String userName = scanner.nextLine();
        System.out.println("You entered: " + userName);
        System.out.println("Enter your roll no : ");
        String userRollno =scanner.nextLine();
        System.out.println("You Entered: "+ userRollno);
        System.out.println("Enter your 3 subject marks : ");
        String userMark1 =scanner.nextLine();
        String userMark2 =scanner.nextLine();
        String userMark3 =scanner.nextLine();
        System.out.println("Your marks of 3 subject are: "+ userMark1+" "+ userMark2 +" "+ userMark3);
     
        scanner.close();
    }

  
}
