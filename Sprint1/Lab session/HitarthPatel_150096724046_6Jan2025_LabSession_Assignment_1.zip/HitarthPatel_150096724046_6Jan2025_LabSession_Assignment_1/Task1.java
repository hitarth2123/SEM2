class Task1{
    /*
       Task 1: Your First Java Program
      Make a program to show: "My First Java Program" Don't peek at solutions, try yourself!
     */
    public static void main(String args[]){
        System.out.println("My First Java Program");
    }
}