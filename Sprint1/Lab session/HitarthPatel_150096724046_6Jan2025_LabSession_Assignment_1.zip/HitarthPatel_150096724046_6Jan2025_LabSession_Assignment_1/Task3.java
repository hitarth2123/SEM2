/*
  Task 3: Do Calculations
    Calculate:
    Total marks
    Percentage Pass or Fail
    */ 
    import java.util.Scanner;

    class Task3 {
        public static void main(String[]args){
            Scanner scanner = new Scanner(System.in);
            System.out.print("Enter your name : ");
            String userName = scanner.nextLine();
            System.out.println("You entered: " + userName);
            System.out.println("Enter your roll no : ");
            Integer userRollno =scanner.nextInt();
            System.out.println("You Entered: "+ userRollno);
            System.out.println("Enter your 3 subject marks : ");
            Integer userMark1 =scanner.nextInt();
            Integer userMark2 =scanner.nextInt();
            Integer userMark3 =scanner.nextInt();
            System.out.println("Your marks of 3 subject are: "+ userMark1+" "+ userMark2 +" "+ userMark3);
       
            Integer totalMarks = 0;
            totalMarks = userMark1 + userMark2 + userMark3;
            System.out.println("Your total score is "+totalMarks);

            Integer percentage =0;
            percentage=totalMarks/3 *100;
            System.out.println("Your percentage is :"+percentage);

            if (percentage<40){
                System.out.println("You fail ");
            }
            else{
                System.out.println("You pass");
            }



         
            scanner.close();
        }
    
      
    }
    