
name = input("Enter your name: ")
age = input("Enter your age: ")
print("Your name is " + name + " and your age is " + age)

