num1 = int(input("Enter the first number: "))
num2 = int(input("Enter the second number: "))

print("Before swapping:")
print("num1 =", num1)
print("num2 =", num2)

num1, num2 = num2, num1

print("After swapping:")
print("num1 =", num1)
print("num2 =", num2)

