letter = input("Enter a letter: ")
if letter.lower() in 'aeiou':
    print(letter, "is a vowel.")
else:
    print(letter, "is a consonant.")

