pi = 3.14159
radius = float(input("Enter the radius of the circle: "))
area = pi * radius**2
print("The area of the circle is: ", area)

