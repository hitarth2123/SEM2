num1 = int(input("Enter the first number: "))
num2 = int(input("Enter the second number: "))

sum = num1 + num2
difference = num1 - num2
product = num1 * num2
division = num1 / num2
modulus = num1 % num2

print("The sum of the two numbers is: ", sum)
print("The difference of the two numbers is: ", difference)
print("The product of the two numbers is: ", product)
print("The division of the two numbers is: ", division)
print("The modulus of the two numbers is: ", modulus)
