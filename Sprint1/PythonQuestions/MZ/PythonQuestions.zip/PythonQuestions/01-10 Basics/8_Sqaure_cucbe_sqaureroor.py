num = float(input("Enter a number: "))
square = num ** 2
cube = num ** 3
sqrt = num ** 0.5
print(f"Square: {square}, Cube: {cube}, Square Root: {sqrt}")




