decimal = int(input("Enter a decimal integer: "))
binary = bin(decimal)
print("The binary representation is:", binary[2:])

