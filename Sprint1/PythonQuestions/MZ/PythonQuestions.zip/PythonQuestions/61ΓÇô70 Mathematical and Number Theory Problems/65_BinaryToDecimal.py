binary = input("Enter a binary number: ")
decimal = int(binary, 2)
print("Decimal equivalent:", decimal)
