number = int(input("Enter a positive integer: "))
count = len(str(number))
print("Number of digits : ", count)




