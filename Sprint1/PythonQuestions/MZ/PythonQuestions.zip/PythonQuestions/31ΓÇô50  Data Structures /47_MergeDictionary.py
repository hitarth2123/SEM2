dict1 = eval(input("Enter the first dictionary: "))
dict2 = eval(input("Enter the second dictionary: "))
merged_dict = {**dict1, **dict2}
print("Merged Dictionary: ", merged_dict)




