my_dict = {"name": "John", "age": 30, "city": "New York"}
print(my_dict.keys())
print(my_dict.values())

