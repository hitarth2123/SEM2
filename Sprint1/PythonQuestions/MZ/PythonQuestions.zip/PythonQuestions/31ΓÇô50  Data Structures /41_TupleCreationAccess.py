tuple_of_strings = ('apple', 'banana', 'cherry', 'date')
print("Tuple of strings:", tuple_of_strings)
index = int(input("Enter an index: "))
print("Element at index", index, "is", tuple_of_strings[index])

