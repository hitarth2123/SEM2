my_tuple = ("apple", "banana", "cherry")
element = input("Enter an element: ")
if element in my_tuple:
    print(f"{element} exists in the tuple.")
else:
    print(f"{element} does not exist in the tuple.")



