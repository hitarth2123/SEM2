input_string = input("Enter a string: ")
print(' '.join(word.capitalize() for word in input_string.split()))


