input_string = input("Enter a string: ")
input_string = input_string.replace(" ", "")
print("Original String: ", input_string)
print("Output (without spaces): ", input_string)




