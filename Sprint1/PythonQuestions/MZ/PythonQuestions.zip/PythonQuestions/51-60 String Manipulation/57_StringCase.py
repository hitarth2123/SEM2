input_string = input("Enter a string: ")
upper_case = input_string.upper()
lower_case = input_string.lower()
title_case = input_string.title()

print("Upper Case:", upper_case)
print("Lower Case:", lower_case)
print("Title Case:", title_case)



